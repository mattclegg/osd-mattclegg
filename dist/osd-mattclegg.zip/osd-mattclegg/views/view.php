<div class="somc-subpages">
    <div class='row type-33 using-background bottom-glow-inside dark-gradient'>
        <div class="block-33 block-text ">
            <div class="title"><?php echo $title; ?></div>
            <ul role="navigation">
                <?php echo $the_pages; ?>
            </ul>
            <?php if( $can_sort_base_level ): ?><button class="subpages-sort"></button><?php endif; ?>
        </div>
    </div>
</div>